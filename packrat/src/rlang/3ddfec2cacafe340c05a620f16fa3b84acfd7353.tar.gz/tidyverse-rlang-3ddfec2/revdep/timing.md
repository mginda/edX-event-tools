# Check times

|package |version | check_time|
|:-------|:-------|----------:|
|sf      |0.4-3   |      274.7|
|tibble  |1.3.1   |       46.9|



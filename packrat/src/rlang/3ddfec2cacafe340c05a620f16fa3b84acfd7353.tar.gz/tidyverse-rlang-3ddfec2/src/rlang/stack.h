#ifndef RLANG_STACK_H
#define RLANG_STACK_H


void r_on_exit(SEXP expr, SEXP frame);


#endif
